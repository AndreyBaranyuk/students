import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';



const LotsOfStyles = () => {
  return (
    <View style={styles.container}>
      <View style={styles.f1}>
        <Text style={styles.h1}>«Кадиш.com» Натан Ингландер. Издательство «Книжники»</Text>
      </View>
      <View style={styles.f2}>
        <Text style={styles.h2}>Ироничная новелла Натана Ингландера, две личные истории культовой Патти Смит, репортаж британской журналистки о будущем человечества, дебютный роман Оушена Вуонга и журналистское расследование о создании «Моссада». В нашей подборке рассказываем о пяти захватывающих книжных новинках, которые достойны того, чтобы появиться на ваших полках.</Text>
      </View>
    </View>
  );
  };
const styles = StyleSheet.create({
  container:{
    height: "100%",
  },
  f1: {
    backgroundColor: "lightgray",
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
  },
  f2: {
    backgroundColor: "gray",
    flex: 4,
  },
  h1: {
    fontSize: "20px",
    textAlign: "center",
  },
  h2:{
    textAlign: "center",
    fontSize: "14px",
    marginTop: "30px",
    marginLeft: "15px",
    marginRight: "15px",
  },
});
export default LotsOfStyles;