import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';



const LotsOfStyles = () => {
  return (
    <View style={styles.container}>
    <Text style={styles.h1}>Журнал Bright</Text>
    <View style={styles.main}>
      <Text style={styles.link}>Новости</Text>
      <Image source={require("./assets/ph.PNG")}></Image>
      <Text style={styles.h2}>Превращаем стресс в своего помощника</Text>
      <Text>Исследователи Йельского университета заявляют, что люди, которые рассматривают стресс, как возможность личностного роста, отмечают улучшение качества жизни. Сегодня узнаем, как это работает и как увидеть положительные стороны стресса.</Text>
    </View>
    </View>
  );
  };
const styles = StyleSheet.create({
  link:{
    color: "blue",
  },
  container: {
    alignItems: "center",
    backgroundColor: "lightgray",
    height: "100%",
  },
  h1: {
    fontWeight: "bold",
    fontSize: "18px",
    marginTop: "40px",
  },
  h2: {
    fontWeight: "bold",
    fontSize: "24px",
  },
  main: {
    backgroundColor: "white",
    paddingLeft: "30px",
    paddingRight: "30px",
    justifyContent: "space-around",
    height: "60%",
  },
});
export default LotsOfStyles;